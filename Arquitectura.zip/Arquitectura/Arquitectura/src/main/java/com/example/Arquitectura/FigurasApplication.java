package com.example.figuras;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Scanner;

@SpringBootApplication
public class FigurasApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(FigurasApplication.class, args);
    }

    @Override
    public void run(String... args) {
        FiguraFactory factory = new FiguraFactory();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n===== FIGURAS GEOMETRICAS =====");
            System.out.println("1. Crear figura y calcular");
            System.out.println("2. Salir");
            System.out.print("Selecciona una opcion: ");

            if (!scanner.hasNextLine()) {
                return;
            }

            String opcion = scanner.nextLine().trim();

            if (opcion.equals("2")) {
                System.out.println("Programa finalizado.");
                return;
            }

            if (!opcion.equals("1")) {
                System.out.println("Opcion incorrecta.");
                continue;
            }

            try {
                System.out.println("\nFiguras disponibles:");
                System.out.println("Circulo  -> radio");
                System.out.println("Cuadrado -> lado");
                System.out.println("Triangulo -> lado1 lado2 lado3");

                System.out.print("\nNombre de la clase: ");
                String nombre = scanner.nextLine().trim();

                System.out.print("Medidas separadas por espacios: ");
                String entrada = scanner.nextLine().trim();

                if (entrada.isEmpty()) {
                    throw new IllegalArgumentException(
                            "Debes ingresar las medidas."
                    );
                }

                String[] valores = entrada.split("\\s+");
                double[] parametros = new double[valores.length];

                for (int i = 0; i < valores.length; i++) {
                    parametros[i] = Double.parseDouble(
                            valores[i].replace(',', '.')
                    );

                    if (!Double.isFinite(parametros[i])
                            || parametros[i] <= 0) {
                        throw new IllegalArgumentException(
                                "Las medidas deben ser positivas y finitas."
                        );
                    }
                }

                Figura figura = factory.crearFigura(nombre, parametros);

                double area = figura.calcularArea();
                double perimetro = figura.calcularPerimetro();

                if (!Double.isFinite(area) || !Double.isFinite(perimetro)
                        || area <= 0 || perimetro <= 0) {
                    throw new IllegalArgumentException(
                            "Las medidas no producen un resultado valido."
                    );
                }

                System.out.println("\n----- RESULTADO -----");
                System.out.println("Clase: " + figura.getClass().getSimpleName());
                System.out.println("Medidas: " + entrada);
                System.out.printf("Area: %.2f%n", area);
                System.out.printf("Perimetro: %.2f%n", perimetro);

            } catch (NumberFormatException e) {
                System.out.println(
                        "Error: ingresa unicamente medidas numericas."
                );
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}